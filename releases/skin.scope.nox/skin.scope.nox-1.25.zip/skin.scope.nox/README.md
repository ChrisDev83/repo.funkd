# ScopeNox

Feeling grateful? :) If you fancy donating a small amount you can do so <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=YMD9V64RNLYDG&lc=IE&item_name=Funkd%20%2d%20Skin%20Modding&item_number=KODI&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted">here!</a>. If not then that is totally fine also :) 

This is a modified version of AeonNox by BigNoid. So consider donating to him if you like the original Aeon Nox skin!

It is made to suit people with CIH setups that have the resolution at 1920x1080 and have the projector zoomed so that scope images fill the screen.

Using the normal Kodi skins in this case causes part of the skin to spill outside the scope frame onto walls.


This version of the skin contains all the GUI within an 800/820 pixel height. 

To install simply download the zip file and then within Kodi go to AddOns and 'Install from Zip' and it should install.

Latest Release (Krypton) : https://github.com/Funkd/ScopeNox/releases/download/1.22/skin.scope.nox.1.22.zip

Latest Release (Leia)    : https://github.com/Funkd/ScopeNox/releases/download/1.23/skin.scope.nox.1.23.zip

In order to switch between 2.35 and 2.40 format go to :
System -> Appearance -> Skin -> Settings -> Scope -> Scope Format (Toggle)

Any issues, please let me know.
